# I2P+ Licenses and Warranty

I2P+ is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

See https://www.gnu.org/licenses/agpl-3.0.en.html for the full license text.

## NO WARRANTY

BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. THE PROGRAM IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER OR OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM, EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

## STANDARD LICENSES

The following standard licenses are incorporated by reference:
- Apache License 2.0: https://www.apache.org/licenses/LICENSE-2.0
- BSD 3-Clause: https://opensource.org/licenses/BSD-3-Clause
- CC0 1.0 Universal: https://creativecommons.org/publicdomain/zero/1.0/
- GPL 2.0: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
- GPL 3.0: https://www.gnu.org/licenses/gpl-3.0.en.html
- LGPL 2.1: https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
- LGPL 3.0: https://www.gnu.org/licenses/lgpl-3.0.en.html
- MIT License: https://opensource.org/licenses/MIT

## CORE API (i2p.jar)

Public domain except as listed below:

- **AES code (Cryptix)** — Cryptix General License. Copyright (c) 1995-2005 The Cryptix Foundation Limited.
- **Apache httpcomponents** — Apache License 2.0. Copyright (c) The Apache Software Foundation.
- **BlockFile** — BSD-3-Clause. Copyright (c) 2006 Matthew Estes. https://metanotion.net/software/sandbox/block.html
- **Bouncy Castle (ElGamal / AES / SSU HMAC)** — MIT-style. Copyright (c) 2000-2023 The Legion Of The Bouncy Castle Inc.
- **ChaCha20** — MIT License. Copyright (C) 2016 Southern Storm Software, Pty Ltd (derived from Noise protocol).
- **Crypto filters (I2P Project BSD)** — BSD-style. Copyright (c) 2009 The I2P Project.
- **EdDSA (Ed25519)** — CC0 1.0 Universal. Copyright (c) 2015-2019 the str4d project contributors.
- **ElGamal and DSA code** — BSD-style. Copyright (c) 2003 TheCrypto.
- **GNU getopt** — LGPLv2. Copyright (c) 1987-1997 Free Software Foundation / 1998 Aaron M. Renn.
- **GNU gettext** — LGPLv2.1+. Copyright (C) 2001, 2007, 2015-2016 Free Software Foundation.
- **GNU Crypto (Fortuna PRNG)** — GPLv2+ with linking exception. Copyright (C) 2004 Free Software Foundation, Inc.
- **json-simple** — Apache License 2.0. Copyright (c) 2011-2019 The json-simple Authors.
- **MiniDNS** — Apache License 2.0 / LGPLv2.1+ / WTFPL (triple-licensed). Copyright (c) 2015-2021 the MiniDNS project authors.
- **Noise protocol** — MIT License. Copyright (C) 2016 Southern Storm Software, Pty Ltd.
- **SNTP code** — BSD-style. Copyright (c) 2004 Adam Buckley.
- **SSLEepGet (InstallCert)** — BSD-style. Copyright 2006 Sun Microsystems.
- **Android array utilities (ratchet)** — Apache License 2.0. Copyright (C) 2006 The Android Open Source Project.
- **CachedIteratorCollection** — GPLv2 with Classpath exception. Copyright (c) 1997, 2013, Oracle and/or its affiliates.

## JAVA SERVICE WRAPPER

GPLv2/GPLv3. Tanuki Software Wrapper. Community Software License Agreement v1.3. https://wrapper.tanukisoftware.com/doc/english/licenseCommunity.html#text

## JBIGI LIBRARIES (jbigi.jar)

- **JNI code** — Public Domain
- **GMP 6.3.0** — LGPL 3.0 or GPL 2.0 (dual licensed)

## SOURCE CODE

Source code available at https://github.com/I2PPlus/i2pplus

## APPLICATIONS

**Addressbook**
MIT License. Copyright (c) 2004 Ragnarok.

**Desktopgui**
GPLv2. Copyright (C) 2009 Mathias De Maré.

**I2PControl**
Apache v2.0. Copyright (c) 2011 hottuna (dev@robertfoss.se).

**I2PSnark**
GPLv2. I2P port of Snark, the BitTorrent client written by Mark J. Wielaard (Copyright (C) 2003, klomp.org); ported to I2P by the I2P Project. License text: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

**I2PTunnel**
GPLv2+. Copyright (c) 2003-2004 mihi, 2004 human (SOCKS). With special exception for proprietary Java linking.

**Imagegen - Identicon**
MIT License. Copyright (c) 2007-2014 Don Park. Contributor 2014 Paulo Miguel Almeida Rodenas.

**Imagegen - JRObin QR Code**
LGPLv2.1+. Contains QR code encoding adapted from jrobin. Copyright (c) 2001-2005 Sasa Markovic and Ciaran Treanor. Copyright (c) 2011 The OpenNMS Group, Inc.

**Imagegen - OpenSSH RandomArt**
BSD-style. Copyright (c) 2000, 2001 Markus Friedl. Copyright (c) 2008 Alexander von Gernler.

**SusiMail / SusiDNS**
GPLv2+. Copyright (C) 2004-2005 susi23@mail.i2p.

**Ministreaming Lib**
The i2p/apps/ministreaming module is the root of the ministreaming library, and everything within it is released according to the terms of the I2P license policy. That means everything contained within the i2p/apps/ministreaming module is released under a BSD license unless otherwise marked. Alternate licenses that may be used include Cryptix, MIT, as well as code granted into the public domain.

**Router Console NDT subsystem**
Copyright (c) 2003 University of Chicago. All rights reserved. The Web100 Network Diagnostic Tool (NDT) is distributed subject to the following license conditions:
1. The "Software" refers to the Web100 Network Diagnostic Tool (NDT). Each licensee is addressed as "you" or "Licensee."
2. The copyright holder hereby grants Licensee a royalty-free nonexclusive license, subject to the limitations stated herein and U.S. Government license rights.
3. You may modify and make a copy or copies of the Software for use within your organization.
4. You may make a copy, or modify a copy or copies of the Software or any portion of it, thus forming a work based on the Software, and distribute copies outside your organization.
5. Portions of the Software resulted from work developed under a U.S. Government contract.
6. WARRANTY DISCLAIMER. THE SOFTWARE IS SUPPLIED "AS IS" WITHOUT WARRANTY OF ANY KIND.
7. LIMITATION OF LIABILITY. IN NO EVENT WILL THE COPYRIGHT HOLDER, THE UNITED STATES, THE UNITED STATES DEPARTMENT OF ENERGY, OR THEIR EMPLOYEES BE LIABLE FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL OR PUNITIVE DAMAGES.

## PUBLIC DOMAIN COMPONENTS

The following components are in the public domain:
- **Proxyscript** (i2pProxy.pac)
- **Router Console** (routerconsole.jar, routerconsole.war)
- **SAM** (sam.jar)
- **Streaming Lib** (streaming.jar)
- **Systray** (systray.jar)

## GEOIP

- **GeoIP library (MaxMind)** — LGPLv2. Copyright (C) 2003-2004 MaxMind LLC.
- **GeoLite2 Country (db-ip)** — CC BY-SA 4.0 - https://db-ip.com/db/
- **db-ip ASN Lite (db-ip)** — CC BY-SA 4.0 - https://db-ip.com/db/
- **countries.txt** — CC BY-SA 3.0 (MaxMind GeoLite Country, discontinued)

## JETTY

This product includes software developed by the Eclipse Foundation (Jetty) under the Apache License 2.0 and Eclipse Public License 1.0.

Eclipse Public License 1.0: Copyright (c) Eclipse Contributors. All rights reserved. This program and the accompanying materials are made available under the terms of the Eclipse Public License v. 2.0 which accompanies this distribution. A copy of the EPL 1.0 is available at https://www.eclipse.org/legal/epl-v20.html.

Jetty is derived from code by Mort Bay Consulting Pty. Ltd. Copyright (c) 1995-2017 Mort Bay Consulting Pty. Ltd.

## APACHE TOMCAT

Apache Tomcat. Copyright 1999-2025 The Apache Software Foundation.

This product includes software developed at The Apache Software Foundation (https://www.apache.org/). This software contains code derived from netty-native developed by the Netty project (https://netty.io/) and from finagle-native developed at Twitter (https://github.com/twitter/finagle).

## SPOTBUGS

LGPLv2.1. Bundled dependencies: ASM (BSD 3-Clause), Commons, DocBook XSL, Dom4j, Error Prone, Gson, Jaxen, JCIP, JSR305, Log4j, Logback (EPL/LGPL), Saxon-HE, SLF4J, XML Resolver (various licenses).

## IMAGE RENDERING

- **ZXing (QR code)** — Apache License 2.0. Copyright 2007 ZXing authors. https://github.com/zxing/zxing
- **JFreeSVG** — GPLv3+ (commercial license available from Object Refinery Limited). Copyright (c) 2013-2020, Object Refinery Limited.
- **RRD4J (jrobin.jar)** — Apache License 2.0. https://github.com/rrd4j/rrd4j
- **Crinch hashing** — Apache License 2.0. Copyright 2010 Tom Gibara.
- **RyuDouble** — Apache License 2.0. Copyright 2018 Ulf Adams.

## PACK200 (apps/pack200)

GPLv2 only with Classpath exception. Copyright (c) Oracle and/or its affiliates. Derived from OpenJDK.

## FREENET / UPnP

GPLv2+. Contains code from Freenet (DetectedIP, UPnP). Copyright (c) The Freenet Project.

## FREESOFTWARE / ACNS (Cybergarage UPnP)

Copyright (C) Satoshi Konno 2002-2004. No explicit license text accompanies this code.

## XLATTICE

BSD-style. Copyright (c) The xlattice Project (Bloom filter).

## WTFPL

- **I2PTunnelHTTPBidirProxy** — WTFPL v2. Copyright (C) sponge. Do What The F*ck You Want To Public License.

## JAVASCRIPT LIBRARIES

The following third-party JavaScript libraries are bundled:

- **HtmlSanitizer** — MIT License. Copyright (c) 2016-2024 Alexander Yumashev, Jitbit Software. https://github.com/jitbit/HtmlSanitizer
- **iframe-resizer** — GPL-2.0. https://github.com/davidjbradshaw/iframe-resizer
- **jdenticon** (v3.3.0) — MIT License. https://jdenticon.com
- **lightbox** — MIT License. Based on jsOnlyLightbox (https://github.com/felixhagspiel/jsOnlyLightbox)
- **morphdom** — MIT License. https://github.com/patrick-steele-idem/morphdom
- **progressx** — MIT License. https://github.com/ryadpasha/progressx
- **snowflakes** — MIT License. https://github.com/hcodes/snowflakes/
- **tablesort** — MIT License. Copyright (c) 2012 tristen. https://github.com/tristen/tablesort
- **vdomParser** — MIT License. Fork of @thednp/domparser (Copyright 2026 © thednp, https://github.com/thednp/domparser) with I2P+ modifications for exact browser-DOM equivalence on console markup (verbatim text, single-pass entity decoding, HTML5-lite table rules).

## IDENTICON (apps/imagegen/identicon/)

MIT License. Copyright (c) 2007-2014 Don Park, 2014 Paulo Miguel Almeida Rodenas. https://github.com/rocambille/identicon4j

## CUSTOM JAVASCRIPT

The following custom JavaScript scripts were written by dr|z3d for I2P+. Licensed under AGPL-3.0 or later.

- **Console**: geomap (based on CartoSVG mercator example), initResizer, updatedEvent, viewprofile, tunnels, tunnelpeercount, translationReport, transitsummary, transit, transitfast, toggleElements, tableSectionToggler, stickySidebar, stats, sortWorker, sectionToggle, searchLS, refreshSidebar, refreshOnClick, refreshLogs, refreshElements, profiles, peers, onVisible, ok, newHosts, netdbLookup, netdb, miniGraph, lsDebug, lsCompact, lazyload, jobs, graphs, graphSingle, formsubmit, fetchWorker, detectPageZoom, convertKBtoMB, configtunnels, configstats, clickToClose, changelog, advconfig
- **I2PSnark**: tunnelCounter, toggleVaryTunnelLength, togglePriorities, toggleLinks, toggleDebug, textView, snarkWork, snarkSort, snarkAlert, setFilterQuery, refreshTorrents, pageNav, getImgDimensions, filterBar, convertTooltips, click
- **I2PTunnel**: toggleThrottler, refreshIndex, filterTunnels
- **ImageGen**: imagegen
- **SusiDNS**: togglePanels, toggleAllHosts, refreshStatus, deleteHosts, clearSearch
- **SusiMail**: toggleHeaders, sanitizeHTML, refreshInbox, previewMail, notifications, htmlView, folder, deleteMail, compose, markdown

## CONSOLE / WEBAPPS THEMES & GRAPHICS

Custom console and webapp themes and graphics authored by dr|z3d. Licensed under AGPL-3.0 or later unless specified otherwise.

### FONTS

- **FiraCode** — SIL Open Font License. https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
- **Sora** — SIL Open Font License. https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
- **Open Sans** — SIL Open Font License, Version 1.1. https://openfontlicense.org/open-font-license-official-text/
