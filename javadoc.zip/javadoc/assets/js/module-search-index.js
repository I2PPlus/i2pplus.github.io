moduleSearchIndex=[],updateSearchResults();
